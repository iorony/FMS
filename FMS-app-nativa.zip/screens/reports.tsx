import { useEffect, useMemo, useState } from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { supabase } from "../lib/supabase";
import { C, STATUS_LABEL, Status } from "../theme";
import { errorMessage, formatDate, formatDateTime } from "../lib/format";
import { Badge, Button, Card, EmptyState, Input, Loading, Metric, SectionTitle, ToastBar, useToast } from "../components/ui";
import { SelectField, SelectSheet, type Option } from "../components/select-sheet";

type ReportRow = { id: string; work_date: string; technician_id: string; technician_name: string; hourly_rate: number | null; clock_in_at: string | null; clock_out_at: string | null; worked_minutes: number | null; regular_minutes: number | null; overtime_minutes: number | null; estimated_payment: number | null };
type OperationalRow = { id: string; code: string; status: Status; scheduled_at: string | null; client_name: string; technician_id: string | null; technician_name: string | null; evidence_count: number; material_entries: number; has_customer_signature: boolean; has_gps_start: boolean; has_gps_end: boolean };
type AttendanceFilter = "" | "completa" | "abierta" | "extra" | "sin_tarifa";

const ATTENDANCE_OPTIONS: Option[] = [
  { id: "", label: "Todas las jornadas" }, { id: "completa", label: "Completas" }, { id: "abierta", label: "Abiertas" }, { id: "extra", label: "Con horas extra" }, { id: "sin_tarifa", label: "Sin tarifa" },
];
const STATUS_OPTIONS: Option[] = [{ id: "", label: "Todos los estados" }, ...Object.entries(STATUS_LABEL).map(([id, label]) => ({ id, label }))];
const COMPLIANCE_OPTIONS: Option[] = [{ id: "", label: "Todo cumplimiento" }, { id: "completo", label: "Expediente completo" }, { id: "pendiente", label: "Con pendientes" }];

function minutes(value: number | null) { if (value === null || value === undefined) return "—"; const hours = Math.floor(value / 60); const rest = value % 60; return hours ? `${hours} h${rest ? ` ${rest} min` : ""}` : `${rest} min`; }
function money(value: number | null) { return value === null || value === undefined ? "Tarifa pendiente" : `Q ${Number(value).toFixed(2)}`; }
function attendanceTime(value: string | null, missing: string) { return value ? formatDateTime(value) : missing; }
function attendancePayment(row: ReportRow) { return !row.clock_out_at ? "Pendiente de salida" : row.hourly_rate === null ? "Tarifa pendiente" : row.estimated_payment === null ? "Pago pendiente de cálculo" : money(row.estimated_payment); }
function validDate(value: string) { return !value || /^\d{4}-\d{2}-\d{2}$/.test(value); }
function complete(row: OperationalRow) { return row.has_gps_start && row.has_gps_end && row.evidence_count > 0 && row.material_entries > 0 && row.has_customer_signature; }

async function shareCsv(filename: string, rows: (string | number | null)[][]) {
  const escape = (value: string | number | null) => { const text = String(value ?? ""); return /[",;\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text; };
  const csv = `\uFEFF${rows.map((row) => row.map(escape).join(",")).join("\r\n")}`;
  if (Platform.OS === "web") {
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url; link.download = filename;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }
  const file = new File(Paths.cache, filename);
  file.write(csv);
  if (!await Sharing.isAvailableAsync()) throw new Error("Este dispositivo no permite compartir archivos.");
  await Sharing.shareAsync(file.uri, { mimeType: "text/csv", dialogTitle: "Compartir reporte" });
}

/** Misma base que web: rango Desde/Hasta, técnico y tipo de jornada. */
export function ReportsScreen({ technician = false }: { technician?: boolean }) {
  const [rows, setRows] = useState<ReportRow[] | null>(null);
  const [technicians, setTechnicians] = useState<Option[]>([]);
  const [fromDraft, setFromDraft] = useState(""); const [toDraft, setToDraft] = useState("");
  const [technicianDraft, setTechnicianDraft] = useState(""); const [attendanceDraft, setAttendanceDraft] = useState<AttendanceFilter>("");
  const [filters, setFilters] = useState({ from: "", to: "", technicianId: "", attendance: "" as AttendanceFilter });
  const [sheet, setSheet] = useState<"technician" | "attendance" | null>(null);
  const [error, setError] = useState<string | null>(null); const { toast, show, hide } = useToast();

  useEffect(() => { if (!technician) supabase.from("profiles").select("id,full_name").eq("role", "technician").eq("is_active", true).order("full_name").then(({ data }) => setTechnicians([{ id: "", label: "Todos los técnicos" }, ...(data ?? []).map((item) => ({ id: item.id, label: item.full_name }))])); }, [technician]);
  useEffect(() => {
    let active = true;
    let query = supabase.from("daily_payroll_report").select("*").order("work_date", { ascending: false });
    if (filters.from) query = query.gte("work_date", filters.from); if (filters.to) query = query.lte("work_date", filters.to); if (!technician && filters.technicianId) query = query.eq("technician_id", filters.technicianId);
    query.then(({ data, error: queryError }) => { if (!active) return; if (queryError) { setError(errorMessage(queryError, "No fue posible cargar la asistencia.")); setRows([]); } else { let result = (data ?? []) as unknown as ReportRow[]; if (filters.attendance === "completa") result = result.filter((row) => row.clock_in_at && row.clock_out_at); if (filters.attendance === "abierta") result = result.filter((row) => row.clock_in_at && !row.clock_out_at); if (filters.attendance === "extra") result = result.filter((row) => (row.overtime_minutes ?? 0) > 0); if (filters.attendance === "sin_tarifa") result = result.filter((row) => row.hourly_rate === null); setRows(result); setError(null); } });
    return () => { active = false; };
  }, [filters, technician]);

  const verified = useMemo(() => rows?.filter((row) => row.clock_in_at && row.clock_out_at) ?? [], [rows]);
  const regular = verified.reduce((total, row) => total + (row.regular_minutes ?? 0), 0); const overtime = verified.reduce((total, row) => total + (row.overtime_minutes ?? 0), 0); const payment = verified.reduce((total, row) => total + Number(row.estimated_payment ?? 0), 0);
  function apply() { if (!validDate(fromDraft) || !validDate(toDraft) || (fromDraft && toDraft && fromDraft > toDraft)) return show("error", "Ingresa fechas válidas en formato AAAA-MM-DD; Desde no puede ser posterior a Hasta."); setFilters({ from: fromDraft, to: toDraft, technicianId: technicianDraft, attendance: attendanceDraft }); }
  async function exportAttendance() { if (!rows?.length) return show("error", "No hay jornadas con los filtros actuales para exportar."); try { await shareCsv(`preliquidacion-${new Date().toISOString().slice(0, 10)}.csv`, [["Fecha", "Técnico", "Entrada", "Salida", "Horas normales", "Horas extra", "Pago estimado"], ...rows.map((row) => [formatDate(row.work_date), row.technician_name, attendanceTime(row.clock_in_at, "Sin entrada"), attendanceTime(row.clock_out_at, "Sin salida"), minutes(row.regular_minutes), minutes(row.overtime_minutes), attendancePayment(row)])]); show("success", "Preliquidación lista para compartir."); } catch (exportError) { show("error", errorMessage(exportError, "No fue posible exportar el CSV.")); } }

  return <ScrollView contentContainerStyle={reports.body} keyboardShouldPersistTaps="handled">
    <ToastBar toast={toast} onHide={hide} />
    <Card><SectionTitle title="Filtros de asistencia" lead="Usa Desde y Hasta para consultar cualquier periodo." /><View style={reports.filters}><Input value={fromDraft} onChangeText={setFromDraft} placeholder="Desde · AAAA-MM-DD" maxLength={10} /><Input value={toDraft} onChangeText={setToDraft} placeholder="Hasta · AAAA-MM-DD" maxLength={10} />{!technician && <SelectField value={technicians.find((item) => item.id === technicianDraft)?.label} placeholder="Todos los técnicos" onPress={() => setSheet("technician")} />}<SelectField value={ATTENDANCE_OPTIONS.find((item) => item.id === attendanceDraft)?.label} placeholder="Todas las jornadas" onPress={() => setSheet("attendance")} /><Button title="Aplicar filtros" onPress={apply} /></View></Card>
    <Button title="Descargar CSV" variant="secondary" onPress={exportAttendance} />
    {!rows ? <Loading label="Cargando asistencia…" /> : error ? <Card><Text style={reports.error}>{error}</Text></Card> : <>
      <View style={reports.grid}><Metric label="Horas normales" value={minutes(regular)} note="Dentro de la jornada diaria" /><Metric label="Horas extra" value={minutes(overtime)} note="Después de la jornada configurada" tone="work" /><Metric label="Pago estimado" value={money(payment)} note="Incluye multiplicador de horas extra" tone="done" /><Metric label="Jornadas abiertas" value={rows.length - verified.length} note="Falta salida GPS" tone="due" /></View>
      <Card><SectionTitle title={technician ? "Mis jornadas" : "Jornadas y preliquidación"} lead="Se descuenta hasta 1 hora de almuerzo entre 12:00 y 14:00; las horas posteriores a la jornada configurada son extras." />{rows.length ? rows.map((row) => <View key={row.id} style={reports.row}><View style={{ flex: 1 }}><Text style={reports.code}>{formatDate(row.work_date)} · {row.technician_name}</Text><Text style={reports.meta}>GPS: {attendanceTime(row.clock_in_at, "Sin entrada")} → {attendanceTime(row.clock_out_at, "Sin salida")}</Text><Text style={reports.payment}>{minutes(row.regular_minutes)} normales · {minutes(row.overtime_minutes)} extra · {attendancePayment(row)}</Text><Text style={reports.meta}>{row.hourly_rate === null ? "Tarifa por hora pendiente" : `${money(row.hourly_rate)} / hora`}</Text></View></View>) : <EmptyState title="Sin jornadas con estos filtros" text="Cambia las fechas o quita alguno de los filtros." />}</Card>
    </>}
    <SelectSheet visible={sheet === "technician"} title="Filtrar por técnico" options={technicians} selectedId={technicianDraft} onSelect={(option) => { setTechnicianDraft(option.id); setSheet(null); }} onClose={() => setSheet(null)} />
    <SelectSheet visible={sheet === "attendance"} title="Filtrar por jornada" options={ATTENDANCE_OPTIONS} selectedId={attendanceDraft} onSelect={(option) => { setAttendanceDraft(option.id as AttendanceFilter); setSheet(null); }} onClose={() => setSheet(null)} />
  </ScrollView>;
}

/** Módulo independiente para coordinación y administración; no se mezcla con nómina. */
export function OrderReportsScreen({ onOpenOrder }: { onOpenOrder: (id: string) => void }) {
  const [rows, setRows] = useState<OperationalRow[] | null>(null); const [technicians, setTechnicians] = useState<Option[]>([]);
  const [fromDraft, setFromDraft] = useState(""); const [toDraft, setToDraft] = useState(""); const [technicianDraft, setTechnicianDraft] = useState(""); const [statusDraft, setStatusDraft] = useState(""); const [complianceDraft, setComplianceDraft] = useState("");
  const [filters, setFilters] = useState({ from: "", to: "", technicianId: "", status: "", compliance: "" }); const [sheet, setSheet] = useState<"technician" | "status" | "compliance" | null>(null); const [error, setError] = useState<string | null>(null); const { toast, show, hide } = useToast();
  useEffect(() => { supabase.from("profiles").select("id,full_name").eq("role", "technician").eq("is_active", true).order("full_name").then(({ data }) => setTechnicians([{ id: "", label: "Todos los técnicos" }, ...(data ?? []).map((item) => ({ id: item.id, label: item.full_name }))])); }, []);
  useEffect(() => { let active = true; let query = supabase.from("operational_order_report").select("*").order("scheduled_at", { ascending: false }); if (filters.from) query = query.gte("scheduled_at", `${filters.from}T00:00:00-06:00`); if (filters.to) query = query.lte("scheduled_at", `${filters.to}T23:59:59.999-06:00`); if (filters.technicianId) query = query.eq("technician_id", filters.technicianId); if (filters.status) query = query.eq("status", filters.status); query.then(({ data, error: queryError }) => { if (!active) return; if (queryError) { setError(errorMessage(queryError, "No fue posible cargar el reporte de órdenes.")); setRows([]); } else { let result = (data ?? []) as unknown as OperationalRow[]; if (filters.compliance === "completo") result = result.filter(complete); if (filters.compliance === "pendiente") result = result.filter((row) => !complete(row)); setRows(result); setError(null); } }); return () => { active = false; }; }, [filters]);
  const closed = rows?.filter((row) => row.status === "cerrada").length ?? 0; const active = rows?.filter((row) => ["asignada", "en_proceso", "pendiente_de_cierre"].includes(row.status)).length ?? 0; const ready = rows?.filter((row) => row.status === "pendiente_de_cierre" && complete(row)).length ?? 0; const completeCount = rows?.filter(complete).length ?? 0; const attention = rows?.filter((row) => !complete(row) && !["cerrada", "cancelada"].includes(row.status)) ?? [];
  function apply() { if (!validDate(fromDraft) || !validDate(toDraft) || (fromDraft && toDraft && fromDraft > toDraft)) return show("error", "Ingresa fechas válidas en formato AAAA-MM-DD; Desde no puede ser posterior a Hasta."); setFilters({ from: fromDraft, to: toDraft, technicianId: technicianDraft, status: statusDraft, compliance: complianceDraft }); }
  async function exportOrders() { if (!rows?.length) return show("error", "No hay órdenes con los filtros actuales para exportar."); try { await shareCsv(`reporte-ordenes-${new Date().toISOString().slice(0, 10)}.csv`, [["Orden", "Cliente", "Técnico", "Programada", "Estado", "GPS", "Materiales", "Evidencias", "Firma", "Cumplimiento"], ...rows.map((row) => [row.code, row.client_name, row.technician_name ?? "Sin asignar", formatDateTime(row.scheduled_at), STATUS_LABEL[row.status], row.has_gps_start && row.has_gps_end ? "Completo" : "Pendiente", row.material_entries, row.evidence_count, row.has_customer_signature ? "Sí" : "No", complete(row) ? "Completo" : "Pendiente"])]); show("success", "Reporte de órdenes listo para compartir."); } catch (exportError) { show("error", errorMessage(exportError, "No fue posible exportar el CSV.")); } }
  return <ScrollView contentContainerStyle={reports.body} keyboardShouldPersistTaps="handled"><ToastBar toast={toast} onHide={hide} /><Button title="Descargar CSV" variant="secondary" onPress={exportOrders} />{!rows ? <Loading label="Cargando reporte de órdenes…" /> : error ? <Card><Text style={reports.error}>{error}</Text></Card> : <><View style={reports.grid}><Metric label="Órdenes del periodo" value={rows.length} note="Según filtros aplicados" /><Metric label="En ejecución" value={active} note="Órdenes activas" tone="work" /><Metric label="Listas para cierre" value={ready} note="Expediente completo" tone="done" /><Metric label="Cumplimiento documental" value={rows.length ? `${Math.round((completeCount / rows.length) * 100)}%` : "—"} note={`${completeCount} completos · ${closed} cerrados`} tone="due" /></View>{attention.length ? <Card><SectionTitle title="Requieren seguimiento" lead="Órdenes activas con requisitos de cierre pendientes." />{attention.slice(0, 5).map((row) => <Pressable key={row.id} onPress={() => onOpenOrder(row.id)} style={reports.row}><View style={{ flex: 1 }}><Text style={reports.code}>{row.code} · {row.client_name}</Text><Text style={reports.meta}>Falta: {[!row.has_gps_start || !row.has_gps_end ? "GPS" : "", row.material_entries === 0 ? "materiales" : "", row.evidence_count === 0 ? "evidencias" : "", !row.has_customer_signature ? "firma" : ""].filter(Boolean).join(", ")}</Text></View><Badge status={row.status} /></Pressable>)}</Card> : null}<Card><SectionTitle title="Filtros del reporte" lead="Usa Desde y Hasta para consultar cualquier rango de fechas." /><View style={reports.filters}><Input value={fromDraft} onChangeText={setFromDraft} placeholder="Desde · AAAA-MM-DD" maxLength={10} /><Input value={toDraft} onChangeText={setToDraft} placeholder="Hasta · AAAA-MM-DD" maxLength={10} /><SelectField value={technicians.find((item) => item.id === technicianDraft)?.label} placeholder="Todos los técnicos" onPress={() => setSheet("technician")} /><SelectField value={STATUS_OPTIONS.find((item) => item.id === statusDraft)?.label} placeholder="Todos los estados" onPress={() => setSheet("status")} /><SelectField value={COMPLIANCE_OPTIONS.find((item) => item.id === complianceDraft)?.label} placeholder="Todo cumplimiento" onPress={() => setSheet("compliance")} /><Button title="Aplicar filtros" onPress={apply} /></View></Card><Card><SectionTitle title="Órdenes del periodo" lead={`${rows.length} resultado${rows.length === 1 ? "" : "s"} según los filtros.`} />{rows.length ? rows.map((row) => <Pressable key={row.id} onPress={() => onOpenOrder(row.id)} style={reports.row}><View style={{ flex: 1 }}><Text style={reports.code}>{row.code} · {row.client_name}</Text><Text style={reports.meta}>{row.technician_name ?? "Sin técnico"} · {formatDateTime(row.scheduled_at)}</Text><Text style={reports.meta}>{complete(row) ? "Expediente completo" : "Pendiente de expediente"}</Text></View><Badge status={row.status} /></Pressable>) : <EmptyState title="Sin órdenes con estos filtros" text="Cambia las fechas o quita alguno de los filtros." />}</Card></>}<SelectSheet visible={sheet === "technician"} title="Filtrar por técnico" options={technicians} selectedId={technicianDraft} onSelect={(option) => { setTechnicianDraft(option.id); setSheet(null); }} onClose={() => setSheet(null)} /><SelectSheet visible={sheet === "status"} title="Filtrar por estado" options={STATUS_OPTIONS} selectedId={statusDraft} onSelect={(option) => { setStatusDraft(option.id); setSheet(null); }} onClose={() => setSheet(null)} /><SelectSheet visible={sheet === "compliance"} title="Filtrar por cumplimiento" options={COMPLIANCE_OPTIONS} selectedId={complianceDraft} onSelect={(option) => { setComplianceDraft(option.id); setSheet(null); }} onClose={() => setSheet(null)} /></ScrollView>;
}

const reports = StyleSheet.create({ body: { padding: 16, paddingBottom: 40, gap: 14 }, grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 }, filters: { gap: 10, marginTop: 12 }, row: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderTopWidth: 1, borderTopColor: C.lineSoft, paddingTop: 12, marginTop: 12 }, code: { color: C.ink, fontSize: 14, fontWeight: "700" }, meta: { color: C.muted, fontSize: 12, lineHeight: 17, marginTop: 3 }, payment: { color: C.ok, fontSize: 12.5, fontWeight: "800", marginTop: 5 }, error: { color: C.danger, fontSize: 13.5 } });
